// Copyright (c) 2022, opex and contributors
// For license information, please see license.txt

frappe.ui.form.on('Opex Form Library', {
	// refresh: function(frm) {

	// }
});
