from frappe import _

def get_data():
	return [
		{
			"module_name": "Opex",
			"type": "module",
			"label": _("Opex")
		}
	]
